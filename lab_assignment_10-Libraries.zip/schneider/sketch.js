let ball;
let box;

function setup() {
  createCanvas(400, 400);
  colorMode(RGB,255,255,255);
  world.gravity.y = 10;
  
  ball = new Sprite();
  ball.diameter = 50;
  ball.y = 50;

  box = new Sprite();
  box.width = 200;
  box.height = 10;
  box.y = 350;
  box.collider = 'kinematic';
}

function draw() {
  
  box.moveTowards(mouse, 0.10);
  //if(keyIsPressed == true && key == "a"){
  //  box.rotationSpeed = -5;
  //} else if (keyIsPressed == true && key == "d"){
  //  box.rotationSpeed = 5;
  //} else {
  //  box.rotation = 0;
  //}

  if(ball.y >= 450){
      ball.y = 0;
      ball.x = 200;
      ball.velocity.x = 0;
  }

  background(220,20,50);
}