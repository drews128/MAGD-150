let cloudX = [];
let cloudY = [];
let cloudSize = [];
let cloudAngle = [];
let cloudValue = [];

let cloudAmmount = 10;

function setup() {
  createCanvas(600, 600);
  colorMode(RGB,255);
  ellipseMode(RADIUS);
  angleMode(DEGREES);
  
  for(var i = 0; i < cloudAmmount; i++){
    cloudX[i] = random(0,width);
    cloudY[i] = random(0,height);
    cloudSize[i] = random(0.5,1.5);
    cloudAngle[i] = random(-20,20);
    cloudValue[i] = random(200,255);
  }
  
  print(averageValue());
}

function draw() {
  
  if(averageValue() > 230){
    background(100,200,255);
  } else {
    background(130,130,150);
  }
  
  for(var i = 0; i < cloudAmmount; i++){
    cloud(cloudX[i],cloudY[i],cloudSize[i],
      cloudAngle[i],cloudValue[i]);
  }
}

function cloud(x,y,size,angle,value) {
  push();
  
  translate(x,y);
  scale(size);
  rotate(angle);
  
  strokeWeight(0);
  fill(value);
  
  ellipse(80,40,60,60);
  ellipse(0,0,80,80);
  ellipse(-70,35,50,50);
  
  pop();
}

function averageValue(){
  var total = 0;
  for(var i = 0; i < cloudAmmount; i++){
    total += cloudValue[i];
  }
  average = total/cloudAmmount;
  return average;
}