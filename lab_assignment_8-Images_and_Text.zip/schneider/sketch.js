var moon;
var astronaut;
var alien;
var ufo;
var speechbubble;

var ufoX = 690;

function preload(){
  moon = loadImage("moon.jpg");
  astronaut = loadImage("astronaut.png");
  alien = loadImage("alien.png");
  ufo = loadImage("ufo.png");
  speechbubble = loadImage("speechbubble.png");
}

function setup() {
  createCanvas(600, 600);
  colorMode(RGB,255,255,255,1);
  textFont("Helvetica");
  textSize(25);
}

function draw() {
  background(220,220,220);
  
  if(ufoX >= -90){
    ufoX -= 1;
  }else{
    ufoX = 690;
  }

  image(moon,0,0,600,600);
  image(ufo,ufoX,50,80,80);
  image(speechbubble,100,-15,150,150);
  image(alien,100,100,120,200);

  fill(0,0,0);
  strokeWeight(2);
  stroke(180,180,180);

  text("yo i'm an alien",120,30,150,150);

  image(astronaut,mouseX-80,mouseY-100,200,200);
}